import { useEffect, useMemo, useState } from "react";
import { Activity, ArrowLeft, Award, Bell, Check, ChevronDown, CircleHelp, Copy, Crown, Gamepad2, Globe2, LogIn, LogOut, Menu, Plus, Search, ShieldCheck, Sparkles, Swords, Trophy, UserRound, Users, X as CloseIcon } from "lucide-react";
import { isConfigured, roomCode, supabase } from "./lib/supabase";
import { games, rankFor, type GameId } from "./lib/games";
import type { Session } from "@supabase/supabase-js";

type Profile = { id: string; username: string; avatar_url?: string | null; xp: number; total_points: number; wins: number; games_played: number };
type Room = { id: string; code: string; game_id: GameId; owner_id: string; is_private: boolean; status: string; max_players: number; created_at: string };

const demoProfile: Profile = { id: "guest", username: "زائر", xp: 240, total_points: 240, wins: 12, games_played: 27 };
const initials = (name: string) => name.slice(0, 1).toUpperCase();

export default function App() {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile>(demoProfile);
  const [authOpen, setAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState<"login" | "signup">("signup");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [activeGame, setActiveGame] = useState<GameId | null>(null);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [room, setRoom] = useState<Room | null>(null);
  const [members, setMembers] = useState<{ user_id: string; username: string; is_ready: boolean }[]>([]);
  const [roomModal, setRoomModal] = useState(false);
  const [joinCode, setJoinCode] = useState("");
  const [privateRoom, setPrivateRoom] = useState(true);
  const [roomGame, setRoomGame] = useState<GameId>("xo");
  const [roomSize, setRoomSize] = useState(2);
  const [xoBoard, setXoBoard] = useState<(string | null)[]>(Array(9).fill(null));
  const [xoTurn, setXoTurn] = useState("X");
  const [xoWinner, setXoWinner] = useState<string | null>(null);
  const [xoMatchId, setXoMatchId] = useState<string | null>(null);
  const [chatText, setChatText] = useState("");
  const [chat, setChat] = useState<{ id: string; username: string; body: string; created_at: string }[]>([]);
  const [mobileMenu, setMobileMenu] = useState(false);
  const rank = rankFor(profile.xp || 0);
  const progress = Math.max(0, Math.min(100, ((profile.xp - rank.floor) / (rank.next - rank.floor)) * 100));

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => setSession(next));
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!supabase || !session?.user) return;
    let alive = true;
    const load = async () => {
      const { data } = await supabase!.from("profiles").select("*").eq("id", session!.user.id).maybeSingle();
      if (data && alive) setProfile(data as Profile);
      await refreshRooms();
    };
    void load();
    return () => { alive = false; };
  }, [session]);

  useEffect(() => {
    const pathCode = window.location.pathname.match(/\/room\/([A-Za-z0-9]+)/)?.[1];
    if (pathCode) setJoinCode(pathCode.toUpperCase());
  }, []);

  async function refreshRooms() {
    if (!supabase) return;
    const { data } = await supabase.from("rooms").select("id,code,game_id,owner_id,is_private,status,max_players,created_at").eq("status", "waiting").eq("is_private", false).order("created_at", { ascending: false }).limit(8);
    if (data) setRooms(data as Room[]);
  }

  async function authenticate() {
    if (!supabase) { setNotice("اربط Supabase أولًا من ملف .env؛ وضع المعاينة لا ينشئ حسابات حقيقية."); return; }
    if (!email.trim() || password.length < 8) { setNotice("أدخل بريدًا صحيحًا وكلمة مرور من 8 أحرف على الأقل."); return; }
    setBusy(true); setNotice("");
    try {
      if (authMode === "signup") {
        const { data, error } = await supabase.auth.signUp({ email: email.trim(), password, options: { data: { username: username.trim() || email.split("@")[0] } } });
        if (error) throw error;
        if (data.session) setNotice("تم إنشاء الحساب وتسجيل الدخول.");
        else setNotice("تم إرسال رسالة تأكيد إن كان تأكيد البريد مفعّلًا. افتح بريدك ثم سجّل الدخول.");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (error) throw error;
        setNotice("تم تسجيل الدخول بنجاح.");
      }
    } catch (e) { setNotice(e instanceof Error ? e.message : "تعذر إتمام العملية."); }
    finally { setBusy(false); }
  }

  async function signOut() { if (supabase) await supabase.auth.signOut(); setRoom(null); setActiveGame(null); setProfile(demoProfile); }

  async function createRoom() {
    if (!supabase || !session) { setAuthOpen(true); setNotice("سجّل الدخول بعد ربط قاعدة البيانات لإنشاء غرفة حقيقية."); return; }
    setBusy(true); setNotice("");
    try {
      const code = roomCode();
      const { data, error } = await supabase.rpc("create_room", { p_code: code, p_game_id: roomGame, p_is_private: privateRoom, p_max_players: roomSize });
      if (error) throw error;
      const created = data as Room;
      setRoom(created); setActiveGame(roomGame); setRoomModal(false);
      window.history.pushState({}, "", `/room/${created.code}`);
      await loadRoom(created);
    } catch (e) { setNotice(e instanceof Error ? e.message : "تعذر إنشاء الغرفة."); }
    finally { setBusy(false); }
  }

  async function joinRoom(code: string) {
    if (!supabase || !session) { setAuthOpen(true); setNotice("تحتاج إلى تسجيل الدخول للانضمام إلى غرفة."); return; }
    if (!code.trim()) { setNotice("أدخل رمز الغرفة."); return; }
    setBusy(true);
    try {
      const { data, error } = await supabase.rpc("join_room", { p_code: code.trim().toUpperCase() });
      if (error) throw error;
      const joined = data as Room;
      setRoom(joined); setActiveGame(joined.game_id); setJoinCode("");
      window.history.pushState({}, "", `/room/${joined.code}`);
      await loadRoom(joined);
    } catch (e) { setNotice(e instanceof Error ? e.message : "تعذر الانضمام للغرفة."); }
    finally { setBusy(false); }
  }

  async function loadRoom(r: Room) {
    if (!supabase) return;
    const { data: m } = await supabase.from("room_members").select("user_id,is_ready,profiles(username)").eq("room_id", r.id);
    if (m) setMembers(m.map((x: any) => ({ user_id: x.user_id, is_ready: x.is_ready, username: x.profiles?.username || "لاعب" })));
    if (r.game_id === "xo") {
      const { data: match } = await supabase.from("matches").select("id,state,status").eq("room_id", r.id).eq("status", "playing").maybeSingle();
      if (match) { setXoMatchId(match.id); setXoBoard((match.state?.board || Array(9).fill(null)) as (string | null)[]); setXoTurn(match.state?.turn || "X"); setXoWinner(match.state?.winner || null); }
    }
  }

  useEffect(() => {
    if (!supabase || !room) return;
    const channel = supabase.channel(`room-${room.id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "room_members", filter: `room_id=eq.${room.id}` }, () => { void loadRoom(room); })
      .on("postgres_changes", { event: "*", schema: "public", table: "matches", filter: `room_id=eq.${room.id}` }, () => { void loadRoom(room); })
      .on("postgres_changes", { event: "*", schema: "public", table: "room_messages", filter: `room_id=eq.${room.id}` }, (payload) => {
        if (payload.eventType === "INSERT") setChat((old) => [...old, payload.new as any].slice(-100));
      }).subscribe();
    return () => { void supabase!.removeChannel(channel); };
  }, [room?.id]);

  async function readyUp() {
    if (!supabase || !room) return;
    const mine = members.find(m => m.user_id === session?.user.id);
    const { error } = await supabase.from("room_members").update({ is_ready: !mine?.is_ready }).eq("room_id", room.id).eq("user_id", session!.user.id);
    if (error) setNotice(error.message);
    await loadRoom(room);
  }

  async function startMatch() {
    if (!supabase || !room) return;
    const { data, error } = await supabase.rpc("start_match", { p_room_id: room.id });
    if (error) { setNotice(error.message); return; }
    if (room.game_id === "xo") { setXoMatchId(data as string); setXoBoard(Array(9).fill(null)); setXoTurn("X"); setXoWinner(null); }
    else setNotice("بدأت المباراة. هذه اللعبة تحتاج إلى إعداد محركها الخاص قبل احتساب النتائج.");
  }

  async function playXo(index: number) {
    if (!supabase || !room || !xoMatchId || xoWinner || xoBoard[index]) return;
    const { data, error } = await supabase.rpc("play_xo_move", { p_match_id: xoMatchId, p_index: index });
    if (error) { setNotice(error.message); return; }
    const result = data as any;
    setXoBoard(result.board); setXoTurn(result.turn); setXoWinner(result.winner);
    if (result.winner) setNotice(result.winner === "draw" ? "تعادل!" : `الفائز: ${result.winner}`);
  }

  async function sendChat() {
    const body = chatText.trim();
    if (!supabase || !room || !body || body.length > 500) return;
    const { error } = await supabase.from("room_messages").insert({ room_id: room.id, body });
    if (error) setNotice(error.message); else setChatText("");
  }

  async function copyInvite() {
    if (!room) return;
    const url = `${window.location.origin}/room/${room.code}`;
    try { await navigator.clipboard.writeText(url); setNotice("تم نسخ رابط الدعوة."); }
    catch { setNotice(url); }
  }

  const activeGameInfo = useMemo(() => games.find(g => g.id === (room?.game_id || activeGame)), [room, activeGame]);

  return <div className="app-shell">
    <div className="ambient ambient-one" /><div className="ambient ambient-two" />
    <header className="topbar">
      <button className="brand" onClick={() => { setRoom(null); setActiveGame(null); window.history.pushState({}, "", "/"); }} aria-label="الرئيسية">
        <span className="brand-mark"><Swords size={22} /></span><span className="brand-text"><b>BLACK GOLD</b><small>GAMES • PLAY TOGETHER</small></span>
      </button>
      <nav className={`nav-links ${mobileMenu ? "open" : ""}`}>
        <a href="#games" onClick={() => setMobileMenu(false)}>الألعاب</a><a href="#leaderboard" onClick={() => setMobileMenu(false)}>المتصدرون</a><a href="#how" onClick={() => setMobileMenu(false)}>كيف تلعب؟</a>
      </nav>
      <div className="top-actions">
        <button className="icon-btn" title="الإشعارات" onClick={() => setNotice("لا توجد إشعارات جديدة.")}><Bell size={18}/></button>
        {session ? <button className="user-pill" onClick={signOut}><span className="avatar">{initials(profile.username)}</span><span>{profile.username}</span><LogOut size={15}/></button> : <button className="btn btn-gold btn-small" onClick={() => { setAuthMode("signup"); setAuthOpen(true); }}><LogIn size={16}/> دخول / تسجيل</button>}
        <button className="icon-btn menu-toggle" onClick={() => setMobileMenu(!mobileMenu)}><Menu size={20}/></button>
      </div>
    </header>

    {!isConfigured && <div className="setup-banner"><ShieldCheck size={17}/><span><b>وضع المعاينة:</b> الواجهة تعمل، لكن الحسابات والغرف المباشرة تحتاج إعداد Supabase وفق README.</span></div>}
    {notice && <div className="toast" role="status"><span>{notice}</span><button onClick={() => setNotice("")}><CloseIcon size={16}/></button></div>}

    {room ? <main className="room-page">
      <div className="room-head"><button className="back-link" onClick={() => { setRoom(null); setActiveGame(null); window.history.pushState({}, "", "/"); }}><ArrowLeft size={16}/> العودة للرئيسية</button><span className="live-dot">الغرفة {room.status === "waiting" ? "بانتظار اللاعبين" : "مباشرة"}</span></div>
      <section className="room-title-card"><div className="game-icon large">{activeGameInfo?.icon || "🎮"}</div><div><p className="eyebrow">غرفة اللعب • {room.code}</p><h1>{activeGameInfo?.title || "غرفة اللعبة"}</h1><p className="muted">شارك الرابط مع أصدقائك وابدأوا التحدي.</p></div><button className="btn btn-outline" onClick={copyInvite}><Copy size={16}/> نسخ رابط الدعوة</button></section>
      <div className="room-layout"><section className="panel game-panel">
        {room.game_id === "xo" ? <><div className="section-title"><div><p className="eyebrow">المباراة الحالية</p><h2>{xoWinner ? (xoWinner === "draw" ? "انتهت بالتعادل" : `فاز اللاعب ${xoWinner}`) : `الدور على ${xoTurn}`}</h2></div><span className="live-badge">LIVE</span></div>
          <div className="xo-board">{xoBoard.map((cell, i) => <button key={i} className={`xo-cell ${cell === "X" ? "mark-x" : cell === "O" ? "mark-o" : ""}`} disabled={!!cell || !!xoWinner || !xoMatchId} onClick={() => void playXo(i)}>{cell}</button>)}</div>
          {!xoMatchId && <p className="muted center">استعد أنت وصديقك، ثم يبدأ صاحب الغرفة المباراة.</p>}
          {xoWinner && <button className="btn btn-gold full" onClick={() => void startMatch()}>إعادة المباراة</button>}
        </> : <div className="coming-game"><Sparkles size={30}/><h2>{activeGameInfo?.title}</h2><p>تم تجهيز نظام الغرف والدعوات. محرك هذه اللعبة يحتاج استكمال قواعد الجولة قبل تفعيل النتائج التنافسية.</p></div>}
        <div className="room-chat"><div className="section-title"><h3>دردشة الغرفة</h3><span className="muted">رسائل الغرفة فقط</span></div><div className="chat-messages">{chat.map(m => <div key={m.id} className="chat-message"><span className="chat-avatar">{initials(m.username || "ل")}</span><div><b>{m.username || "لاعب"}</b><p>{m.body}</p></div></div>)}{chat.length === 0 && <p className="muted center">ابدأوا الحديث قبل المباراة 👋</p>}</div><form className="chat-form" onSubmit={e => { e.preventDefault(); void sendChat(); }}><input value={chatText} onChange={e => setChatText(e.target.value)} maxLength={500} placeholder="اكتب رسالة..." /><button className="btn btn-gold btn-small" type="submit">إرسال</button></form></div>
      </section><aside className="panel players-panel"><div className="section-title"><div><p className="eyebrow">LOBBY</p><h2>اللاعبون <span className="count">{members.length}/{room.max_players}</span></h2></div><Users size={20}/></div>
        <div className="player-list">{members.map(m => <div className="player-row" key={m.user_id}><span className="avatar">{initials(m.username)}</span><div className="player-meta"><b>{m.username} {m.user_id === room.owner_id && <Crown size={13} className="inline-gold"/>}</b><small>{m.user_id === session?.user.id ? "أنت" : "لاعب"}</small></div><span className={`ready-tag ${m.is_ready ? "is-ready" : ""}`}>{m.is_ready ? "مستعد" : "بانتظار"}</span></div>)}</div>
        <button className="btn btn-outline full" onClick={() => void readyUp()}><Check size={16}/> {members.find(m => m.user_id === session?.user.id)?.is_ready ? "إلغاء الاستعداد" : "أنا مستعد"}</button>
        {room.owner_id === session?.user.id && <button className="btn btn-gold full" onClick={() => void startMatch()} disabled={members.length < (room.game_id === "xo" ? 2 : 2)}><Swords size={16}/> بدء المباراة</button>}
        <div className="room-tip"><ShieldCheck size={16}/><p>لا تشارك رمز الغرفة الخاصة إلا مع من تريد اللعب معهم.</p></div>
      </aside></div>
    </main> : <main>
      <section className="hero">
        <div className="hero-copy"><div className="hero-badge"><span className="gold-dot"/> عالمك، لعبتك، جماعتك</div><h1>اللعب أحلى<br/> <span>مع الربع.</span></h1><p className="hero-description">اجمع أصحابك في مكان واحد، تحدّهم في ألعاب الذكاء والسرعة، واصنعوا ذكريات تستاهل التكرار.</p>
          <div className="hero-actions"><button className="btn btn-gold btn-large" onClick={() => setRoomModal(true)}><Plus size={19}/> أنشئ غرفة لعب</button><button className="btn btn-outline btn-large" onClick={() => { if (!session) setAuthOpen(true); else setNotice("اكتب رمز الغرفة في بطاقة الانضمام أدناه."); }}><Users size={19}/> انضم للأصدقاء</button></div>
          <div className="hero-proof"><div className="proof-avatars"><span>ن</span><span>ع</span><span>م</span><span>+</span></div><p><b>اللعب يبدأ بجمعكم</b><small>ادعُ أصدقاءك وابدأوا التحدي</small></p></div>
        </div>
        <div className="hero-visual"><div className="visual-ring ring-one"/><div className="visual-ring ring-two"/><div className="hero-emblem"><span className="emblem-top">BG</span><Swords size={68} strokeWidth={1.2}/><span className="emblem-bottom">PLAY • COMPETE • REPEAT</span></div><div className="floating-card rank-float"><span className="float-icon"><Trophy size={18}/></span><div><small>أعلى رتبة</small><b>أسطوري</b></div><Sparkles size={18} className="gold-text"/></div><div className="floating-card live-float"><span className="live-dot"/><div><b>الربع ينتظرونك</b><small>أنشئ غرفة الآن</small></div></div><div className="hero-spark spark-a">✦</div><div className="hero-spark spark-b">✧</div></div>
      </section>

      <section className="quick-stats">
        <div className="stat-card"><span className="stat-icon"><Trophy size={18}/></span><div><small>نقاطك</small><b>{session ? profile.total_points : "—"}</b></div><span className="stat-foot">POINTS</span></div>
        <div className="stat-card"><span className="stat-icon"><Award size={18}/></span><div><small>الرتبة الحالية</small><b>{session ? rank.name : "ابدأ رحلتك"}</b></div><span className="stat-foot">RANK</span></div>
        <div className="stat-card"><span className="stat-icon"><Swords size={18}/></span><div><small>الانتصارات</small><b>{session ? profile.wins : "—"}</b></div><span className="stat-foot">WINS</span></div>
        <div className="stat-card"><span className="stat-icon"><Activity size={18}/></span><div><small>المباريات</small><b>{session ? profile.games_played : "—"}</b></div><span className="stat-foot">MATCHES</span></div>
      </section>

      <section className="content-section" id="games"><div className="section-heading"><div><p className="eyebrow">اختر تحديك</p><h2>ساحة الألعاب <span className="gold-text">.</span></h2><p className="muted">ألعاب متنوعة، تحديات مختلفة، والهدف واحد: الفوز.</p></div><span className="section-counter">04 <small>ألعاب</small></span></div>
        <div className="games-grid">{games.map((g, i) => <article className={`game-card game-card-${i}`} key={g.id}><div className="game-card-top"><span className="game-icon">{g.icon}</span><span className="game-tag">{g.tag}</span></div><div className="game-art"><div className={`art-symbol art-${g.id}`}>{g.id === "xo" ? <><span>×</span><span>○</span></> : g.id === "word-clash" ? <><span>ك</span><span>؟</span></> : g.id === "auction" ? <><span>?</span><span>!</span></> : <><span>⚡</span><span>🎯</span></>}</div></div><div className="game-card-body"><p className="game-en">{g.en}</p><h3>{g.title}</h3><p className="game-desc">{g.description}</p><div className="game-card-bottom"><span><Users size={14}/>{g.players}</span><span className="reward"><Trophy size={14}/> +{g.reward}</span></div><button className="btn btn-outline full" onClick={() => { setRoomGame(g.id); setRoomModal(true); }}>العب الآن <ArrowLeft size={16}/></button></div></article>)}</div>
      </section>

      <section className="join-banner"><div className="join-symbol"><Globe2 size={28}/></div><div className="join-copy"><p className="eyebrow">عندك رمز غرفة؟</p><h2>الربع أرسلوا لك دعوة؟</h2><p>اكتب رمز الغرفة وادخل معهم مباشرة.</p></div><form className="join-form" onSubmit={e => { e.preventDefault(); void joinRoom(joinCode); }}><div className="join-input-wrap"><Search size={18}/><input value={joinCode} onChange={e => setJoinCode(e.target.value.toUpperCase())} placeholder="مثال: BG7K2Q" maxLength={6}/></div><button className="btn btn-gold" type="submit" disabled={busy}>دخول الغرفة <ArrowLeft size={16}/></button></form></section>

      <section className="lower-grid"><div className="content-section compact" id="leaderboard"><div className="section-heading"><div><p className="eyebrow">أثبت نفسك</p><h2>لوحة المتصدرين</h2></div><Trophy size={22} className="gold-text"/></div>{session ? <div className="empty-panel"><Trophy size={26}/><h3>ترتيبك ينتظرك</h3><p>ستظهر هنا بيانات المتصدرين بعد إعداد قاعدة البيانات وإكمال أولى المباريات.</p></div> : <div className="empty-panel"><UserRound size={26}/><h3>سجّل لتدخل المنافسة</h3><p>احتفظ بنتائجك، وتابع تقدمك، وتصدر قائمة الأصدقاء.</p><button className="btn btn-gold btn-small" onClick={() => setAuthOpen(true)}>أنشئ حسابك</button></div>}</div>
        <div className="content-section compact" id="how"><div className="section-heading"><div><p className="eyebrow">بكل بساطة</p><h2>كيف تبدأ؟</h2></div><CircleHelp size={22} className="gold-text"/></div><div className="steps-list"><div className="step"><span>01</span><div><b>أنشئ غرفة</b><p>اختر اللعبة وعدد اللاعبين.</p></div></div><div className="step"><span>02</span><div><b>أرسل الدعوة</b><p>شارك الرابط أو رمز الغرفة.</p></div></div><div className="step"><span>03</span><div><b>نافس وارقَ</b><p>العبوا واجمعوا النقاط والإنجازات.</p></div></div></div></div></section>
    </main>}

    <footer className="footer"><div className="footer-brand"><span className="brand-mark small"><Swords size={17}/></span><b>BLACK GOLD GAMES</b></div><span>اللعب يجمعنا • © 2026</span><span className="footer-status"><span className="gold-dot"/> منصة الألعاب الجماعية</span></footer>

    {roomModal && <div className="modal-backdrop" onClick={() => setRoomModal(false)}><div className="modal" onClick={e => e.stopPropagation()}><button className="modal-close" onClick={() => setRoomModal(false)}><CloseIcon size={18}/></button><div className="modal-icon"><Gamepad2 size={24}/></div><p className="eyebrow">جهّز التحدي</p><h2>إنشاء غرفة لعب</h2><p className="muted">اختر اللعبة والإعدادات، ثم أرسل الدعوة لأصحابك.</p><label className="field-label">اللعبة</label><div className="game-select-grid">{games.map(g => <button key={g.id} className={`game-select ${roomGame === g.id ? "selected" : ""}`} onClick={() => { setRoomGame(g.id); setRoomSize(g.id === "xo" ? 2 : 6); }}><span>{g.icon}</span><b>{g.title}</b>{roomGame === g.id && <Check size={15}/>}</button>)}</div><div className="form-row"><label className="field"><span className="field-label">عدد اللاعبين</span><select value={roomSize} onChange={e => setRoomSize(Number(e.target.value))}>{[2,3,4,5,6,7,8,9,10].map(n => <option key={n} value={n}>{n} لاعبين</option>)}</select></label><label className="field"><span className="field-label">نوع الغرفة</span><select value={privateRoom ? "private" : "public"} onChange={e => setPrivateRoom(e.target.value === "private")}><option value="private">خاصة بالدعوة</option><option value="public">عامة</option></select></label></div><button className="btn btn-gold btn-large full" onClick={() => void createRoom()} disabled={busy}><Plus size={18}/>{busy ? "جارٍ الإنشاء..." : "إنشاء الغرفة"}</button>{!session && <p className="modal-hint">ستحتاج إلى تسجيل الدخول لإنشاء غرفة فعلية.</p>}</div></div>}

    {authOpen && <div className="modal-backdrop" onClick={() => setAuthOpen(false)}><div className="modal auth-modal" onClick={e => e.stopPropagation()}><button className="modal-close" onClick={() => setAuthOpen(false)}><CloseIcon size={18}/></button><div className="modal-icon"><ShieldCheck size={24}/></div><p className="eyebrow">حسابك في عالم الألعاب</p><h2>{authMode === "signup" ? "انضم إلى الربع" : "حيّاك من جديد"}</h2><p className="muted">حساب واحد يحفظ تقدمك ونقاطك على كل أجهزتك.</p><div className="auth-tabs"><button className={authMode === "signup" ? "active" : ""} onClick={() => setAuthMode("signup")}>حساب جديد</button><button className={authMode === "login" ? "active" : ""} onClick={() => setAuthMode("login")}>تسجيل الدخول</button></div>{authMode === "signup" && <label className="field"><span className="field-label">اسم المستخدم</span><input value={username} onChange={e => setUsername(e.target.value)} placeholder="اسم يظهر لأصدقائك" maxLength={24}/></label>}<label className="field"><span className="field-label">البريد الإلكتروني</span><input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" autoComplete="email"/></label><label className="field"><span className="field-label">كلمة المرور</span><input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="8 أحرف على الأقل" autoComplete={authMode === "signup" ? "new-password" : "current-password"}/></label><button className="btn btn-gold btn-large full" onClick={() => void authenticate()} disabled={busy}>{busy ? "لحظة..." : authMode === "signup" ? "إنشاء الحساب" : "دخول آمن"} <ArrowLeft size={17}/></button><p className="modal-hint">لا نطلب كلمة المرور إلا عبر خدمة المصادقة الآمنة. لا تستخدم كلمة مرور حساب آخر.</p></div></div>}
  </div>;
}
