export type GameId = "auction" | "xo" | "madaqish" | "word-clash";
export const games: { id: GameId; title: string; en: string; description: string; players: string; icon: string; reward: number; tag: string }[] = [
  { id: "auction", title: "مزاد الأسئلة", en: "QUIZ AUCTION", description: "زايد بالنقاط، جاوب بسرعة، واثبت أنك الأعرف.", players: "2–8 لاعبين", icon: "⚡", reward: 25, tag: "تفكير وسرعة" },
  { id: "xo", title: "إكس أو", en: "TIC TAC TOE", description: "مواجهة ذكية مباشرة بين لاعبين.", players: "لاعبان", icon: "✕", reward: 10, tag: "كلاسيكية" },
  { id: "madaqish", title: "مداقش", en: "MADAQISH", description: "تحديات قصيرة وجولات مليئة بالحماس.", players: "2–8 لاعبين", icon: "🎯", reward: 20, tag: "تحديات" },
  { id: "word-clash", title: "صراع الكلمات", en: "WORD CLASH", description: "قادة يلمّحون، وفريقان يحاولان كشف الكلمات.", players: "4–10 لاعبين", icon: "🗝️", reward: 30, tag: "فرق وتخمين" }
];
export const rankFor = (xp: number) => {
  if (xp >= 5000) return { name: "أسطوري", next: 7000, floor: 5000, color: "#f2c66d" };
  if (xp >= 3000) return { name: "ألماسي", next: 5000, floor: 3000, color: "#9de8ff" };
  if (xp >= 1800) return { name: "بلاتيني", next: 3000, floor: 1800, color: "#c5cbd5" };
  if (xp >= 900) return { name: "ذهبي", next: 1800, floor: 900, color: "#f2c66d" };
  if (xp >= 300) return { name: "فضي", next: 900, floor: 300, color: "#c5cbd5" };
  return { name: "برونزي", next: 300, floor: 0, color: "#c18a5c" };
};
