import { describe, expect, it } from "vitest";
import { rankFor } from "../src/lib/games";

describe("rankFor", () => {
  it("returns bronze for new users", () => expect(rankFor(0).name).toBe("برونزي"));
  it("promotes at thresholds", () => {
    expect(rankFor(300).name).toBe("فضي");
    expect(rankFor(900).name).toBe("ذهبي");
    expect(rankFor(1800).name).toBe("بلاتيني");
    expect(rankFor(3000).name).toBe("ألماسي");
    expect(rankFor(5000).name).toBe("أسطوري");
  });
});
