-- BLACK GOLD GAMES schema
-- Run in Supabase SQL Editor using a fresh project.
create extension if not exists pgcrypto;

create type public.game_id as enum ('auction','xo','madaqish','word-clash');
create type public.room_status as enum ('waiting','playing','finished','expired');
create type public.match_status as enum ('playing','finished','abandoned');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique check (char_length(username) between 3 and 24),
  avatar_url text,
  bio text not null default '' check (char_length(bio) <= 160),
  xp integer not null default 0 check (xp >= 0),
  total_points integer not null default 0 check (total_points >= 0),
  rating integer not null default 1000 check (rating >= 0),
  wins integer not null default 0 check (wins >= 0),
  losses integer not null default 0 check (losses >= 0),
  games_played integer not null default 0 check (games_played >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.rooms (
  id uuid primary key default gen_random_uuid(),
  code text not null unique check (code ~ '^[A-Z0-9]{6}$'),
  game_id public.game_id not null,
  owner_id uuid not null references public.profiles(id) on delete cascade,
  is_private boolean not null default true,
  max_players integer not null default 2 check (max_players between 2 and 10),
  status public.room_status not null default 'waiting',
  expires_at timestamptz not null default now() + interval '8 hours',
  created_at timestamptz not null default now()
);
create index rooms_public_waiting_idx on public.rooms(status, is_private, created_at desc);

create table public.room_members (
  room_id uuid not null references public.rooms(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  is_ready boolean not null default false,
  joined_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now(),
  primary key(room_id,user_id)
);
create index room_members_user_idx on public.room_members(user_id);

create table public.matches (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.rooms(id) on delete cascade,
  game_id public.game_id not null,
  status public.match_status not null default 'playing',
  state jsonb not null default '{}'::jsonb,
  winner_id uuid references public.profiles(id) on delete set null,
  result_key text unique,
  started_at timestamptz not null default now(),
  finished_at timestamptz
);
create index matches_room_status_idx on public.matches(room_id,status);

create table public.match_players (
  match_id uuid not null references public.matches(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  seat integer not null,
  mark text,
  score integer not null default 0,
  primary key(match_id,user_id),
  unique(match_id,seat)
);

create table public.point_ledger (
  id bigint generated always as identity primary key,
  user_id uuid not null references public.profiles(id) on delete cascade,
  match_id uuid references public.matches(id) on delete set null,
  delta integer not null,
  reason text not null,
  created_at timestamptz not null default now(),
  unique(user_id,match_id,reason)
);
create table public.rank_history (
  id bigint generated always as identity primary key,
  user_id uuid not null references public.profiles(id) on delete cascade,
  rank_name text not null,
  xp_at_change integer not null,
  created_at timestamptz not null default now()
);

create table public.friend_requests (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  receiver_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'pending' check(status in ('pending','accepted','rejected')),
  created_at timestamptz not null default now(),
  unique(sender_id,receiver_id),
  check(sender_id <> receiver_id)
);
create table public.room_messages (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.rooms(id) on delete cascade,
  user_id uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  body text not null check(char_length(body) between 1 and 500),
  created_at timestamptz not null default now()
);
create index room_messages_room_created_idx on public.room_messages(room_id,created_at);

create table public.achievements (
  id text primary key,
  title text not null,
  description text not null,
  xp_reward integer not null default 0 check(xp_reward >= 0)
);
insert into public.achievements(id,title,description,xp_reward) values
 ('first-win','أول فوز','حقق أول انتصار لك',25),
 ('ten-wins','عشرة انتصارات','حقق عشرة انتصارات',75),
 ('multi-game','متعدد المواهب','فز في ثلاث ألعاب مختلفة',100)
 on conflict do nothing;

create table public.user_achievements (
  user_id uuid not null references public.profiles(id) on delete cascade,
  achievement_id text not null references public.achievements(id) on delete cascade,
  earned_at timestamptz not null default now(),
  primary key(user_id,achievement_id)
);

create table public.quiz_questions (
  id uuid primary key default gen_random_uuid(),
  category text not null,
  difficulty smallint not null check(difficulty between 1 and 3),
  question text not null,
  choices jsonb not null check(jsonb_typeof(choices)='array'),
  answer_index smallint not null check(answer_index between 0 and 5),
  explanation text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
create table public.madaqish_challenges (
  id uuid primary key default gen_random_uuid(),
  category text not null,
  difficulty smallint not null check(difficulty between 1 and 3),
  prompt text not null,
  challenge_type text not null default 'text',
  active boolean not null default true
);
create table public.word_clash_boards (
  id uuid primary key default gen_random_uuid(),
  words jsonb not null check(jsonb_typeof(words)='array'),
  solution jsonb not null,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
-- IMPORTANT: secret solutions are only read by trusted server functions; do not expose this table to anon/authenticated clients.
create table public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  reported_user_id uuid references public.profiles(id) on delete set null,
  room_id uuid references public.rooms(id) on delete set null,
  reason text not null check(char_length(reason) between 5 and 1000),
  status text not null default 'open' check(status in ('open','reviewing','resolved','dismissed')),
  created_at timestamptz not null default now()
);
create table public.admin_users (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now()
);

-- Automatically create a profile after sign-up. Username collision is handled by adding a short suffix.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare base_name text; candidate text;
begin
  base_name := coalesce(nullif(trim(new.raw_user_meta_data->>'username'),''), split_part(new.email,'@',1), 'player');
  base_name := regexp_replace(base_name, '[^a-zA-Z0-9_ء-ي-]', '', 'g');
  base_name := left(base_name, 18);
  candidate := base_name;
  if exists(select 1 from public.profiles where username = candidate) then
    candidate := left(base_name, 17) || substr(replace(new.id::text,'-',''),1,6);
  end if;
  insert into public.profiles(id,username) values(new.id,candidate);
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

create or replace function public.is_room_member(p_room_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
 select exists(select 1 from public.room_members where room_id=p_room_id and user_id=auth.uid())
$$;
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
 select exists(select 1 from public.admin_users where user_id=auth.uid())
$$;

alter table public.profiles enable row level security;
alter table public.rooms enable row level security;
alter table public.room_members enable row level security;
alter table public.matches enable row level security;
alter table public.match_players enable row level security;
alter table public.point_ledger enable row level security;
alter table public.rank_history enable row level security;
alter table public.friend_requests enable row level security;
alter table public.room_messages enable row level security;
alter table public.achievements enable row level security;
alter table public.user_achievements enable row level security;
alter table public.quiz_questions enable row level security;
alter table public.madaqish_challenges enable row level security;
alter table public.word_clash_boards enable row level security;
alter table public.reports enable row level security;
alter table public.admin_users enable row level security;

create policy "Profiles visible to authenticated users" on public.profiles for select to authenticated using(true);
create policy "Users update own safe profile fields" on public.profiles for update to authenticated using(id=auth.uid()) with check(id=auth.uid());
create policy "Public waiting rooms are discoverable" on public.rooms for select to authenticated using((not is_private and status='waiting') or owner_id=auth.uid() or public.is_room_member(id) or public.is_admin());
create policy "Room members visible to members" on public.room_members for select to authenticated using(public.is_room_member(room_id) or user_id=auth.uid() or public.is_admin());
create policy "Member can update own readiness" on public.room_members for update to authenticated using(user_id=auth.uid() and public.is_room_member(room_id)) with check(user_id=auth.uid());
create policy "Match visible to room members" on public.matches for select to authenticated using(public.is_room_member(room_id) or public.is_admin());
create policy "Match players visible to room members" on public.match_players for select to authenticated using(exists(select 1 from public.matches m where m.id=match_id and public.is_room_member(m.room_id)));
create policy "Ledger visible to owner/admin" on public.point_ledger for select to authenticated using(user_id=auth.uid() or public.is_admin());
create policy "Rank history visible to owner/admin" on public.rank_history for select to authenticated using(user_id=auth.uid() or public.is_admin());
create policy "Friend requests visible to participants" on public.friend_requests for select to authenticated using(sender_id=auth.uid() or receiver_id=auth.uid() or public.is_admin());
create policy "Members can read room chat" on public.room_messages for select to authenticated using(public.is_room_member(room_id));
create policy "Members can send room chat" on public.room_messages for insert to authenticated with check(user_id=auth.uid() and public.is_room_member(room_id));
create policy "Achievements are public" on public.achievements for select to authenticated using(true);
create policy "Own achievements visible" on public.user_achievements for select to authenticated using(user_id=auth.uid() or public.is_admin());
create policy "Active quiz questions available" on public.quiz_questions for select to authenticated using(active=true);
create policy "Active challenges available" on public.madaqish_challenges for select to authenticated using(active=true);
create policy "Reports create and own view" on public.reports for insert to authenticated with check(reporter_id=auth.uid());
create policy "Reporter or admin reads reports" on public.reports for select to authenticated using(reporter_id=auth.uid() or public.is_admin());
create policy "Admin management profiles" on public.profiles for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "Admin manage questions" on public.quiz_questions for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "Admin manage challenges" on public.madaqish_challenges for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "Admin manage secret boards" on public.word_clash_boards for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "Admin manage reports" on public.reports for update to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "Admin read ledger" on public.point_ledger for select to authenticated using(public.is_admin());
create policy "Admin read admin list" on public.admin_users for select to authenticated using(user_id=auth.uid());
-- Secret board solutions have no authenticated/anon SELECT policy. Server-side RPC must validate role before returning any solution.

-- All authoritative room/game changes occur in database functions, never direct client inserts/updates.
revoke insert, update, delete on public.rooms from anon, authenticated;
revoke insert, delete on public.room_members from anon, authenticated;
revoke insert, update, delete on public.matches from anon, authenticated;
revoke insert, update, delete on public.match_players from anon, authenticated;
revoke insert, update, delete on public.point_ledger from anon, authenticated;
revoke insert, update, delete on public.rank_history from anon, authenticated;
revoke insert, update, delete on public.profiles from anon, authenticated;
grant update(username,avatar_url,bio) on public.profiles to authenticated;
grant update(is_ready,last_seen_at) on public.room_members to authenticated;
grant select on public.profiles,public.rooms,public.room_members,public.matches,public.match_players,public.point_ledger,public.rank_history,public.friend_requests,public.room_messages,public.achievements,public.user_achievements,public.quiz_questions,public.madaqish_challenges to authenticated;
grant insert on public.room_messages,public.reports to authenticated;

create or replace function public.create_room(p_code text,p_game_id public.game_id,p_is_private boolean,p_max_players integer)
returns public.rooms language plpgsql security definer set search_path=public as $$
declare r public.rooms;
begin
 if auth.uid() is null then raise exception 'يجب تسجيل الدخول أولاً'; end if;
 if p_max_players < 2 or p_max_players > 10 then raise exception 'عدد اللاعبين غير صالح'; end if;
 if p_game_id='xo' and p_max_players<>2 then raise exception 'إكس أو تدعم لاعبين فقط'; end if;
 insert into public.rooms(code,game_id,owner_id,is_private,max_players) values(upper(p_code),p_game_id,auth.uid(),p_is_private,p_max_players) returning * into r;
 insert into public.room_members(room_id,user_id) values(r.id,auth.uid());
 return r;
end $$;

create or replace function public.join_room(p_code text)
returns public.rooms language plpgsql security definer set search_path=public as $$
declare r public.rooms;
begin
 if auth.uid() is null then raise exception 'يجب تسجيل الدخول أولاً'; end if;
 select * into r from public.rooms where code=upper(trim(p_code)) for update;
 if not found or r.status<>'waiting' or r.expires_at<now() then raise exception 'الغرفة غير موجودة أو انتهت صلاحيتها'; end if;
 if r.is_private and not exists(select 1 from public.room_members where room_id=r.id and user_id=auth.uid()) then
   -- The short code acts as an invite secret. Only users with the code can join.
   null;
 end if;
 if (select count(*) from public.room_members where room_id=r.id) >= r.max_players and not exists(select 1 from public.room_members where room_id=r.id and user_id=auth.uid()) then raise exception 'الغرفة ممتلئة'; end if;
 insert into public.room_members(room_id,user_id) values(r.id,auth.uid()) on conflict do nothing;
 return r;
end $$;

create or replace function public.start_match(p_room_id uuid)
returns uuid language plpgsql security definer set search_path=public as $$
declare r public.rooms; m public.matches; n integer;
begin
 select * into r from public.rooms where id=p_room_id for update;
 if not found or r.owner_id<>auth.uid() then raise exception 'صاحب الغرفة فقط يستطيع بدء المباراة'; end if;
 if r.status<>'waiting' then raise exception 'الغرفة ليست بانتظار بدء المباراة'; end if;
 select count(*) into n from public.room_members where room_id=r.id;
 if n<2 then raise exception 'تحتاج الغرفة إلى لاعبين على الأقل'; end if;
 if exists(select 1 from public.room_members where room_id=r.id and is_ready=false) then raise exception 'يجب أن يكون جميع اللاعبين مستعدين'; end if;
 if r.game_id='xo' and n<>2 then raise exception 'إكس أو تتطلب لاعبين اثنين'; end if;
 insert into public.matches(room_id,game_id,state) values(r.id,r.game_id,jsonb_build_object('board',jsonb_build_array(null,null,null,null,null,null,null,null,null),'turn','X','winner',null)) returning * into m;
 insert into public.match_players(match_id,user_id,seat,mark)
 select m.id,user_id,row_number() over(order by joined_at),case when row_number() over(order by joined_at)=1 then 'X' else 'O' end from public.room_members where room_id=r.id;
 update public.rooms set status='playing' where id=r.id;
 return m.id;
end $$;

create or replace function public.play_xo_move(p_match_id uuid,p_index integer)
returns jsonb language plpgsql security definer set search_path=public as $$
declare m public.matches; r public.rooms; b jsonb; mark text; win text; next_turn text; i integer; lines integer[][] := array[
 array[0,1,2],array[3,4,5],array[6,7,8],array[0,3,6],array[1,4,7],array[2,5,8],array[0,4,8],array[2,4,6]
];
begin
 if auth.uid() is null then raise exception 'يجب تسجيل الدخول'; end if;
 if p_index<0 or p_index>8 then raise exception 'حركة غير صالحة'; end if;
 select * into m from public.matches where id=p_match_id for update;
 if not found or m.status<>'playing' or m.game_id<>'xo' then raise exception 'المباراة غير نشطة'; end if;
 select * into r from public.rooms where id=m.room_id;
 if not exists(select 1 from public.room_members where room_id=r.id and user_id=auth.uid()) then raise exception 'لست عضوًا في هذه الغرفة'; end if;
 select mp.mark into mark from public.match_players mp where mp.match_id=m.id and mp.user_id=auth.uid();
 if mark is null then raise exception 'لست لاعبًا في هذه المباراة'; end if;
 b:=m.state->'board';
 if b->>p_index is not null then raise exception 'هذه الخانة محجوزة'; end if;
 if m.state->>'turn'<>mark then raise exception 'ليس دورك الآن'; end if;
 b:=jsonb_set(b,array[p_index::text],to_jsonb(mark),false);
 win:=null;
 for i in 1..8 loop
   if b->>lines[i][1]=b->>lines[i][2] and b->>lines[i][2]=b->>lines[i][3] and b->>lines[i][1] in ('X','O') then win:=b->>lines[i][1]; exit; end if;
 end loop;
 if win is null and not exists(select 1 from generate_series(0,8) n where b->>n::text is null) then win:='draw'; end if;
 next_turn:=case when mark='X' then 'O' else 'X' end;
 update public.matches set state=jsonb_build_object('board',b,'turn',case when win is null then next_turn else m.state->>'turn' end,'winner',win),status=case when win is null then 'playing' else 'finished' end,finished_at=case when win is null then null else now() end,winner_id=case when win is null or win='draw' then null else (select user_id from public.match_players where match_id=m.id and match_players.mark=win) end where id=m.id;
 if win is not null then
   update public.rooms set status='finished' where id=r.id;
   if win='draw' then
     update public.profiles p set games_played=games_played+1 where p.id in(select user_id from public.match_players where match_id=m.id);
   else
     update public.profiles p set games_played=games_played+1,wins=wins+case when p.id=(select user_id from public.match_players where match_id=m.id and match_players.mark=win) then 1 else 0 end,losses=losses+case when p.id<>(select user_id from public.match_players where match_id=m.id and match_players.mark=win) then 1 else 0 end where p.id in(select user_id from public.match_players where match_id=m.id);
     insert into public.point_ledger(user_id,match_id,delta,reason) select user_id,m.id,case when match_players.mark=win then 10 else 0 end,case when match_players.mark=win then 'xo_win' else 'xo_loss' end from public.match_players where match_id=m.id on conflict do nothing;
     update public.profiles p set total_points=total_points+10,xp=xp+10,rating=rating+12 where p.id=(select user_id from public.match_players where match_id=m.id and match_players.mark=win);
   end if;
 end if;
 return jsonb_build_object('board',b,'turn',case when win is null then next_turn else m.state->>'turn' end,'winner',win);
end $$;

grant execute on function public.create_room(text,public.game_id,boolean,integer) to authenticated;
grant execute on function public.join_room(text) to authenticated;
grant execute on function public.start_match(uuid) to authenticated;
grant execute on function public.play_xo_move(uuid,integer) to authenticated;

-- Enable Realtime for tables the app subscribes to. If already published, ignore duplicate publication errors.
do $$ begin
 alter publication supabase_realtime add table public.room_members;
exception when duplicate_object then null; when undefined_object then null; end $$;
do $$ begin
 alter publication supabase_realtime add table public.matches;
exception when duplicate_object then null; when undefined_object then null; end $$;
do $$ begin
 alter publication supabase_realtime add table public.room_messages;
exception when duplicate_object then null; when undefined_object then null; end $$;
